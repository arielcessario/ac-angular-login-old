'use strict';

describe('myApp.verify-login module', function() {

  beforeEach(module('myApp.view2'));

  describe('verify-login controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view2Ctrl = $controller('View2Ctrl');
      expect(view2Ctrl).toBeDefined();
    }));

  });
});